"""
Configuración del sistema LuisVet SEO AI
"""
import os
from dotenv import load_dotenv

load_dotenv()

# API Keys
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY', '')
GOOGLE_API_KEY = os.getenv('GOOGLE_API_KEY', '')
SEARCH_ENGINE_ID = os.getenv('SEARCH_ENGINE_ID', '')
BLOGGER_BLOG_ID = os.getenv('BLOGGER_BLOG_ID', '')

# Configuración de OpenAI
OPENAI_MODEL = os.getenv('OPENAI_MODEL', 'gpt-4-turbo-preview')
OPENAI_TEMPERATURE = float(os.getenv('OPENAI_TEMPERATURE', '0.7'))
OPENAI_MAX_TOKENS = int(os.getenv('OPENAI_MAX_TOKENS', '4000'))

# Configuración de búsqueda
SERP_RESULTS_COUNT = int(os.getenv('SERP_RESULTS_COUNT', '10'))
KEYWORD_DIFFICULTY_THRESHOLD = int(os.getenv('KEYWORD_DIFFICULTY_THRESHOLD', '50'))

# Configuración de generación de contenido
MIN_ARTICLE_LENGTH = int(os.getenv('MIN_ARTICLE_LENGTH', '2000'))
MAX_ARTICLE_LENGTH = int(os.getenv('MAX_ARTICLE_LENGTH', '5000'))
INCLUDE_IMAGES = os.getenv('INCLUDE_IMAGES', 'true').lower() == 'true'
INCLUDE_SCHEMA = os.getenv('INCLUDE_SCHEMA', 'true').lower() == 'true'
INCLUDE_FAQS = os.getenv('INCLUDE_FAQS', 'true').lower() == 'true'

# Configuración de Blogger
BLOGGER_PUBLISH_MODE = os.getenv('BLOGGER_PUBLISH_MODE', 'draft')  # 'draft' o 'live'
BLOGGER_ADD_LABELS = os.getenv('BLOGGER_ADD_LABELS', 'veterinaria,salud animal,perros,gatos').split(',')

# Configuración de imágenes
IMAGE_GENERATION_MODEL = os.getenv('IMAGE_GENERATION_MODEL', 'dall-e-3')
IMAGE_SIZE = os.getenv('IMAGE_SIZE', '1024x1024')
IMAGES_PER_ARTICLE = int(os.getenv('IMAGES_PER_ARTICLE', '3'))

# Directorios
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
PROMPTS_DIR = os.path.join(BASE_DIR, 'prompts')

# Crear directorio de datos si no existe
os.makedirs(DATA_DIR, exist_ok=True)

# Logging
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
LOG_FILE = os.path.join(DATA_DIR, 'luisvet.log')
