# LuisVet SEO AI - Sistema de Generación de Contenido Veterinario

Sistema modular basado en agentes especializados para generar contenido veterinario optimizado para SEO, EEAT y GEO.

## Arquitectura

```
luis-vet-seo-ai/
│
├── app.py                 # Punto de entrada principal
├── config.py              # Configuración del sistema
├── requirements.txt       # Dependencias
├── prompts/               # Prompts para cada agente
├── agents/                # Agentes especializados
├── utils/                 # Utilidades comunes
├── data/                  # Datos temporales
└── notebooks/             # Notebook para Colab
```

## Flujo de Trabajo

1. **KEYWORD** → keyword_agent.py
2. **SERP ANALYZER** → serp_agent.py
3. **NLP/ENTIDADES** → entity_agent.py
4. **EEAT** → eeat_agent.py
5. **MEDICAL REVIEW** → medical_agent.py
6. **ARTICLE** → writer_agent.py
7. **HTML** → html_utils.py
8. **SEO** → seo_agent.py
9. **AEO/GEO** → geo_agent.py
10. **IMAGE** → image_agent.py
11. **SCHEMA** → schema_agent.py
12. **BLOGGER** → blogger_agent.py
13. **INDEXING** → google_utils.py
14. **UPDATE** → update_agent.py

## Instalación en Google Colab

### Paso 1: Clonar el repositorio

```python
!git clone https://github.com/luisarturo88/luis-vet-seo-ai.git
%cd luis-vet-seo-ai
```

### Paso 2: Instalar dependencias

```python
!pip install -r requirements.txt
```

### Paso 3: Configurar variables de entorno

```python
import os
os.environ['OPENAI_API_KEY'] = 'tu-api-key-aqui'
os.environ['GOOGLE_API_KEY'] = 'tu-google-api-key-aqui'
os.environ['SEARCH_ENGINE_ID'] = 'tu-search-engine-id-aqui'
```

### Paso 4: Ejecutar el sistema

```python
!python app.py --keyword "parvovirus canino" --output "article.html"
```

## Uso desde línea de comandos

```bash
# Ejecutar todo el flujo
python app.py --keyword "parvovirus canino"

# Ejecutar solo análisis de keywords
python app.py --keyword "parvovirus canino" --step keyword

# Ejecutar hasta generación de artículo
python app.py --keyword "parvovirus canino" --step article

# Publicar en Blogger
python app.py --keyword "parvovirus canino" --publish
```

## Configuración

Edita `config.py` para personalizar:

- API Keys
- Parámetros de generación
- Plantillas de prompts
- Configuración de Blogger
- Opciones de SEO

## Estructura de Agentes

Cada agente es independiente y puede ejecutarse por separado:

```python
from agents.keyword_agent import KeywordAgent
from agents.serp_agent import SerpAgent
from agents.writer_agent import WriterAgent

# Ejemplo de uso individual
keyword_agent = KeywordAgent()
keywords = keyword_agent.analyze("parvovirus canino")

serp_agent = SerpAgent()
serp_data = serp_agent.analyze(keywords[0])

writer_agent = WriterAgent()
article = writer_agent.generate(serp_data)
```

## Fases de Desarrollo

- ✅ **Fase 1**: Arquitectura modular (COMPLETADA)
- 🔄 **Fase 2**: Agentes SEO y SERP
- ⏳ **Fase 3**: Generación de contenido, EEAT, GEO
- ⏳ **Fase 4**: Integración Blogger, imágenes, indexación

## Licencia

MIT
