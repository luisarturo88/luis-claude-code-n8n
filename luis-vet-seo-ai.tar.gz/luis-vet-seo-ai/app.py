"""
LuisVet SEO AI - Sistema de Generación de Contenido Veterinario

Punto de entrada principal que orquesta todos los agentes.
"""
import argparse
import logging
from datetime import datetime
from typing import Optional

from config import (
    DATA_DIR, LOG_LEVEL, LOG_FILE,
    OPENAI_API_KEY, GOOGLE_API_KEY, SEARCH_ENGINE_ID
)

# Configurar logging
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


def validate_setup():
    """Validar que las API keys estén configuradas."""
    errors = []
    
    if not OPENAI_API_KEY:
        errors.append("OPENAI_API_KEY no configurada")
    if not GOOGLE_API_KEY:
        errors.append("GOOGLE_API_KEY no configurada")
    if not SEARCH_ENGINE_ID:
        errors.append("SEARCH_ENGINE_ID no configurado")
    
    if errors:
        logger.error("Errores de configuración:")
        for error in errors:
            logger.error(f"  - {error}")
        logger.error("\nPor favor configura las variables de entorno o crea un archivo .env")
        return False
    
    logger.info("✓ Configuración validada correctamente")
    return True


def run_keyword_analysis(keyword: str) -> dict:
    """Ejecutar análisis de keywords."""
    logger.info(f"🔍 Iniciando análisis de keyword: {keyword}")
    
    try:
        from agents.keyword_agent import KeywordAgent
        agent = KeywordAgent()
        result = agent.analyze(keyword)
        logger.info(f"✓ Análisis completado: {len(result.get('keywords', []))} keywords encontradas")
        return result
    except Exception as e:
        logger.error(f"Error en análisis de keywords: {e}")
        return {"error": str(e), "keywords": []}


def run_serp_analysis(keyword: str) -> dict:
    """Ejecutar análisis SERP."""
    logger.info(f"📊 Analizando SERP para: {keyword}")
    
    try:
        from agents.serp_agent import SerpAgent
        agent = SerpAgent()
        result = agent.analyze(keyword)
        logger.info(f"✓ SERP analizado: {len(result.get('results', []))} resultados")
        return result
    except Exception as e:
        logger.error(f"Error en análisis SERP: {e}")
        return {"error": str(e), "results": []}


def run_entity_extraction(content: str) -> dict:
    """Extraer entidades y construir grafo de conocimiento."""
    logger.info("🔗 Extrayendo entidades...")
    
    try:
        from agents.entity_agent import EntityAgent
        agent = EntityAgent()
        result = agent.extract(content)
        logger.info(f"✓ Entidades extraídas: {len(result.get('entities', []))} entidades")
        return result
    except Exception as e:
        logger.error(f"Error en extracción de entidades: {e}")
        return {"error": str(e), "entities": []}


def run_medical_review(content: str) -> dict:
    """Revisión médica del contenido."""
    logger.info("🏥 Realizando revisión médica...")
    
    try:
        from agents.medical_agent import MedicalAgent
        agent = MedicalAgent()
        result = agent.review(content)
        logger.info("✓ Revisión médica completada")
        return result
    except Exception as e:
        logger.error(f"Error en revisión médica: {e}")
        return {"error": str(e)}


def run_eeat_optimization(content: str) -> dict:
    """Optimizar para EEAT."""
    logger.info("⭐ Optimizando EEAT...")
    
    try:
        from agents.eeat_agent import EEATAgent
        agent = EEATAgent()
        result = agent.optimize(content)
        logger.info("✓ Optimización EEAT completada")
        return result
    except Exception as e:
        logger.error(f"Error en optimización EEAT: {e}")
        return {"error": str(e)}


def run_geo_optimization(content: str) -> dict:
    """Optimizar para GEO (Generative Engine Optimization)."""
    logger.info("🤖 Optimizando para GEO...")
    
    try:
        from agents.geo_agent import GEOAgent
        agent = GEOAgent()
        result = agent.optimize(content)
        logger.info("✓ Optimización GEO completada")
        return result
    except Exception as e:
        logger.error(f"Error en optimización GEO: {e}")
        return {"error": str(e)}


def run_schema_generation(content: str) -> dict:
    """Generar datos estructurados Schema.org."""
    logger.info("📋 Generando Schema.org...")
    
    try:
        from agents.schema_agent import SchemaAgent
        agent = SchemaAgent()
        result = agent.generate(content)
        logger.info("✓ Schema.org generado")
        return result
    except Exception as e:
        logger.error(f"Error en generación de Schema: {e}")
        return {"error": str(e)}


def run_image_generation(keywords: list, count: int = 3) -> dict:
    """Generar imágenes para el artículo."""
    logger.info(f"🎨 Generando {count} imágenes...")
    
    try:
        from agents.image_agent import ImageAgent
        agent = ImageAgent()
        result = agent.generate(keywords, count)
        logger.info(f"✓ Imágenes generadas: {len(result.get('images', []))}")
        return result
    except Exception as e:
        logger.error(f"Error en generación de imágenes: {e}")
        return {"error": str(e), "images": []}


def run_article_generation(serp_data: dict, entities: dict, medical_review: dict) -> dict:
    """Generar artículo completo."""
    logger.info("✍️ Generando artículo...")
    
    try:
        from agents.writer_agent import WriterAgent
        agent = WriterAgent()
        result = agent.generate(serp_data, entities, medical_review)
        logger.info(f"✓ Artículo generado: {len(result.get('content', ''))} caracteres")
        return result
    except Exception as e:
        logger.error(f"Error en generación de artículo: {e}")
        return {"error": str(e)}


def run_blogger_publish(content: str, title: str, labels: list = None) -> dict:
    """Publicar en Blogger."""
    logger.info("📝 Publicando en Blogger...")
    
    try:
        from agents.blogger_agent import BloggerAgent
        agent = BloggerAgent()
        result = agent.publish(content, title, labels)
        logger.info(f"✓ Publicado en Blogger: {result.get('url', 'URL no disponible')}")
        return result
    except Exception as e:
        logger.error(f"Error en publicación Blogger: {e}")
        return {"error": str(e)}


def run_full_pipeline(keyword: str, publish: bool = False):
    """Ejecutar pipeline completo."""
    logger.info("=" * 60)
    logger.info(f"🚀 Iniciando pipeline completo para: {keyword}")
    logger.info("=" * 60)
    
    start_time = datetime.now()
    results = {}
    
    # Paso 1: Análisis de keywords
    results['keywords'] = run_keyword_analysis(keyword)
    if not results['keywords'].get('keywords'):
        logger.warning("⚠️ No se encontraron keywords, usando la original")
        results['keywords'] = {'keywords': [keyword]}
    
    primary_keyword = results['keywords']['keywords'][0]
    
    # Paso 2: Análisis SERP
    results['serp'] = run_serp_analysis(primary_keyword)
    
    # Paso 3: Extracción de entidades
    serp_content = str(results['serp'])
    results['entities'] = run_entity_extraction(serp_content)
    
    # Paso 4: Generación de artículo
    results['article'] = run_article_generation(
        results['serp'],
        results['entities'],
        {}
    )
    
    # Paso 5: Revisión médica
    if 'content' in results['article']:
        results['medical'] = run_medical_review(results['article']['content'])
    
    # Paso 6: Optimización EEAT
    if 'content' in results['article']:
        results['eeat'] = run_eeat_optimization(results['article']['content'])
    
    # Paso 7: Optimización GEO
    if 'content' in results['article']:
        results['geo'] = run_geo_optimization(results['article']['content'])
    
    # Paso 8: Generación de Schema
    if 'content' in results['article']:
        results['schema'] = run_schema_generation(results['article']['content'])
    
    # Paso 9: Generación de imágenes
    results['images'] = run_image_generation(
        results['keywords'].get('keywords', [keyword]),
        count=3
    )
    
    # Paso 10: Publicar en Blogger (opcional)
    if publish and 'content' in results['article']:
        title = results['article'].get('title', f"Artículo sobre {keyword}")
        results['blogger'] = run_blogger_publish(
            results['article']['content'],
            title,
            ['veterinaria', keyword.replace(' ', '-')]
        )
    
    # Guardar resultados
    output_file = f"{DATA_DIR}/results_{keyword.replace(' ', '_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    
    import json
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2, default=str)
    
    end_time = datetime.now()
    duration = end_time - start_time
    
    logger.info("=" * 60)
    logger.info(f"✅ Pipeline completado en {duration}")
    logger.info(f"📁 Resultados guardados en: {output_file}")
    logger.info("=" * 60)
    
    return results


def main():
    parser = argparse.ArgumentParser(
        description='LuisVet SEO AI - Sistema de Generación de Contenido Veterinario'
    )
    parser.add_argument(
        '--keyword', '-k',
        type=str,
        required=True,
        help='Keyword principal para generar el artículo'
    )
    parser.add_argument(
        '--step', '-s',
        type=str,
        choices=['keyword', 'serp', 'entity', 'medical', 'eeat', 'geo', 'schema', 'image', 'article', 'full'],
        default='full',
        help='Paso específico a ejecutar (default: full)'
    )
    parser.add_argument(
        '--publish', '-p',
        action='store_true',
        help='Publicar automáticamente en Blogger'
    )
    parser.add_argument(
        '--validate', '-v',
        action='store_true',
        help='Solo validar configuración'
    )
    
    args = parser.parse_args()
    
    # Validar configuración
    if args.validate or not validate_setup():
        return 1
    
    # Ejecutar paso específico o pipeline completo
    if args.step == 'full':
        run_full_pipeline(args.keyword, publish=args.publish)
    elif args.step == 'keyword':
        run_keyword_analysis(args.keyword)
    elif args.step == 'serp':
        run_serp_analysis(args.keyword)
    elif args.step == 'entity':
        run_entity_extraction(args.keyword)
    elif args.step == 'medical':
        run_medical_review(args.keyword)
    elif args.step == 'eeat':
        run_eeat_optimization(args.keyword)
    elif args.step == 'geo':
        run_geo_optimization(args.keyword)
    elif args.step == 'schema':
        run_schema_generation(args.keyword)
    elif args.step == 'image':
        run_image_generation([args.keyword])
    elif args.step == 'article':
        run_article_generation({}, {}, {})
    
    return 0


if __name__ == '__main__':
    exit(main())
