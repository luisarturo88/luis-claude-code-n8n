"""
Agente de análisis SERP para LuisVet SEO AI

Este agente analiza los primeros resultados de Google y extrae:
- Estructura de headings (H1, H2, H3)
- Tablas y listas
- Preguntas frecuentes
- Entidades mencionadas
- Longitud del contenido
- Keywords principales
- Imágenes y vídeos
- Enlaces internos y externos
"""
import logging
import json
from typing import Dict, List, Optional
from openai import OpenAI
import requests
from bs4 import BeautifulSoup

from config import (
    OPENAI_API_KEY, OPENAI_MODEL, OPENAI_TEMPERATURE,
    GOOGLE_API_KEY, SEARCH_ENGINE_ID, SERP_RESULTS_COUNT
)

logger = logging.getLogger(__name__)


class SerpAgent:
    """Agente especializado en análisis de SERP."""
    
    def __init__(self):
        self.client = OpenAI(api_key=OPENAI_API_KEY)
        self.google_api_key = GOOGLE_API_KEY
        self.search_engine_id = SEARCH_ENGINE_ID
    
    def search_google(self, query: str, num_results: int = 10) -> List[Dict]:
        """
        Realizar búsqueda en Google Custom Search API.
        
        Args:
            query: Término de búsqueda
            num_results: Número de resultados a devolver
            
        Returns:
            Lista de resultados de búsqueda
        """
        logger.info(f"Buscando en Google: {query}")
        
        try:
            url = "https://www.googleapis.com/customsearch/v1"
            params = {
                'key': self.google_api_key,
                'cx': self.search_engine_id,
                'q': query,
                'num': min(num_results, 10)
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            results = []
            
            for item in data.get('items', []):
                results.append({
                    'title': item.get('title', ''),
                    'link': item.get('link', ''),
                    'snippet': item.get('snippet', ''),
                    'display_link': item.get('displayLink', '')
                })
            
            logger.info(f"✓ {len(results)} resultados obtenidos")
            return results
            
        except Exception as e:
            logger.error(f"Error en búsqueda Google: {e}")
            return []
    
    def fetch_page_content(self, url: str) -> Optional[str]:
        """
        Obtener contenido HTML de una URL.
        
        Args:
            url: URL de la página
            
        Returns:
            Contenido HTML o None si hay error
        """
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            return response.text
        except Exception as e:
            logger.warning(f"No se pudo obtener {url}: {e}")
            return None
    
    def analyze_page_structure(self, html: str) -> Dict:
        """
        Analizar estructura de una página HTML.
        
        Args:
            html: Contenido HTML
            
        Returns:
            Diccionario con la estructura analizada
        """
        try:
            soup = BeautifulSoup(html, 'lxml')
            
            # Extraer headings
            h1 = [h.get_text(strip=True) for h in soup.find_all('h1')]
            h2 = [h.get_text(strip=True) for h in soup.find_all('h2')]
            h3 = [h.get_text(strip=True) for h in soup.find_all('h3')]
            
            # Extraer listas
            lists = []
            for ul in soup.find_all(['ul', 'ol']):
                items = [li.get_text(strip=True) for li in ul.find_all('li', limit=10)]
                if items:
                    lists.append(items)
            
            # Extraer tablas
            tables = []
            for table in soup.find_all('table', limit=3):
                rows = []
                for tr in table.find_all('tr', limit=5):
                    cells = [td.get_text(strip=True) for td in tr.find_all(['td', 'th'])]
                    if cells:
                        rows.append(cells)
                if rows:
                    tables.append(rows)
            
            # Contar palabras
            text = soup.get_text()
            word_count = len(text.split())
            
            # Extraer imágenes
            images = [
                img.get('src', '') for img in soup.find_all('img', limit=10)
                if img.get('src')
            ]
            
            # Extraer enlaces
            internal_links = []
            external_links = []
            for link in soup.find_all('a', href=True, limit=20):
                href = link['href']
                if href.startswith('http'):
                    external_links.append(href)
                else:
                    internal_links.append(href)
            
            return {
                'h1': h1,
                'h2': h2,
                'h3': h3,
                'lists': lists,
                'tables': tables,
                'word_count': word_count,
                'images': images,
                'internal_links': internal_links,
                'external_links': external_links
            }
            
        except Exception as e:
            logger.error(f"Error analizando estructura: {e}")
            return {}
    
    def analyze(self, keyword: str) -> Dict:
        """
        Analizar SERP completo para una keyword.
        
        Args:
            keyword: Keyword a analizar
            
        Returns:
            Diccionario con el análisis completo del SERP
        """
        logger.info(f"Analizando SERP para: {keyword}")
        
        results = {
            'keyword': keyword,
            'search_results': [],
            'common_headings': [],
            'common_questions': [],
            'avg_word_count': 0,
            'content_patterns': [],
            'entities': [],
            'recommended_structure': {}
        }
        
        # Paso 1: Búsqueda en Google
        search_results = self.search_google(keyword, SERP_RESULTS_COUNT)
        results['search_results'] = search_results
        
        if not search_results:
            logger.warning("No se obtuvieron resultados de búsqueda")
            return results
        
        # Paso 2: Analizar cada resultado
        all_structures = []
        for i, result in enumerate(search_results[:5]):  # Analizar top 5
            url = result.get('link')
            if url:
                html = self.fetch_page_content(url)
                if html:
                    structure = self.analyze_page_structure(html)
                    all_structures.append(structure)
        
        # Paso 3: Extraer patrones comunes
        if all_structures:
            # Headings comunes
            all_h2 = []
            all_h3 = []
            total_words = 0
            
            for struct in all_structures:
                all_h2.extend(struct.get('h2', []))
                all_h3.extend(struct.get('h3', []))
                total_words += struct.get('word_count', 0)
            
            results['common_headings'] = list(set(all_h2))[:10]
            results['common_subheadings'] = list(set(all_h3))[:15]
            results['avg_word_count'] = total_words // len(all_structures)
            
            # Extraer preguntas (contenido que contiene "?")
            questions = [
                h for h in all_h2 + all_h3 
                if '?' in h
            ]
            results['common_questions'] = list(set(questions))[:10]
        
        # Paso 4: Generar estructura recomendada con IA
        results['recommended_structure'] = self._generate_recommended_structure(
            keyword, results
        )
        
        logger.info(f"✓ SERP analizado completado")
        return results
    
    def _generate_recommended_structure(self, keyword: str, serp_data: Dict) -> Dict:
        """
        Generar estructura recomendada usando IA.
        
        Args:
            keyword: Keyword principal
            serp_data: Datos del análisis SERP
            
        Returns:
            Estructura recomendada para el contenido
        """
        try:
            prompt = f"""
Analiza estos datos SERP para la keyword "{keyword}" y recomienda una estructura óptima:

Headings comunes encontrados:
{json.dumps(serp_data.get('common_headings', [])[:5], ensure_ascii=False)}

Preguntas frecuentes:
{json.dumps(serp_data.get('common_questions', [])[:5], ensure_ascii=False)}

Longitud promedio: {serp_data.get('avg_word_count', 0)} palabras

Proporciona una estructura recomendada en formato JSON:
{{
    "h1": "título principal recomendado",
    "h2_sections": ["sección 1", "sección 2", ...],
    "h3_subsections": {{"sección 1": ["sub 1", "sub 2"], ...}},
    "recommended_length": número,
    "must_include_topics": ["tema 1", "tema 2", ...],
    "content_gaps": ["oportunidad 1", "oportunidad 2", ...]
}}
"""
            
            response = self.client.chat.completions.create(
                model=OPENAI_MODEL,
                messages=[
                    {
                        "role": "system",
                        "content": "Eres un experto en SEO. Responde solo con JSON válido."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.5,
                max_tokens=1500,
                response_format={"type": "json_object"}
            )
            
            return json.loads(response.choices[0].message.content)
            
        except Exception as e:
            logger.error(f"Error generando estructura recomendada: {e}")
            return {
                "h1": f"Guía completa sobre {keyword}",
                "h2_sections": ["Introducción", "Qué es", "Síntomas", "Tratamiento", "Prevención"],
                "recommended_length": serp_data.get('avg_word_count', 2000),
                "must_include_topics": [],
                "content_gaps": []
            }


# Ejemplo de uso
if __name__ == "__main__":
    agent = SerpAgent()
    result = agent.analyze("parvovirus canino")
    print(json.dumps(result, indent=2, ensure_ascii=False)[:2000])
