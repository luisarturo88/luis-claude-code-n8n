"""
Writer Agent - Generación de artículos veterinarios
"""
import logging
import json
from typing import Dict, List
from openai import OpenAI
from config import OPENAI_API_KEY, OPENAI_MODEL, OPENAI_TEMPERATURE

logger = logging.getLogger(__name__)


class WriterAgent:
    """Agente especializado en generación de contenido veterinario."""
    
    def __init__(self):
        self.client = OpenAI(api_key=OPENAI_API_KEY)
    
    def generate(self, serp_data: Dict, entities: Dict, medical_review: Dict) -> Dict:
        """Generar artículo completo."""
        logger.info("Generando artículo...")
        
        try:
            prompt = f"""
Eres un veterinario experto y redactor SEO. Genera un artículo completo sobre veterinaria.

Datos SERP: {json.dumps(serp_data, ensure_ascii=False)[:1000]}
Entidades principales: {json.dumps(entities.get('entities', [])[:5], ensure_ascii=False)}

Requisitos:
- Mínimo 2000 palabras
- Estructura clara con H1, H2, H3
- Lenguaje profesional pero accesible
- Información basada en evidencia científica
- Incluir síntomas, causas, diagnóstico, tratamiento, prevención
- Tono empático y educativo

Formato JSON:
{{
    "title": "título del artículo",
    "meta_description": "descripción para SEO",
    "content": "contenido en markdown",
    "outline": ["sección 1", "sección 2", ...],
    "word_count": número
}}
"""
            
            response = self.client.chat.completions.create(
                model=OPENAI_MODEL,
                messages=[
                    {"role": "system", "content": "Eres un veterinario experto en redacción SEO."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=4000,
                response_format={"type": "json_object"}
            )
            
            result = json.loads(response.choices[0].message.content)
            logger.info(f"✓ Artículo generado: {result.get('word_count', 0)} palabras")
            return result
            
        except Exception as e:
            logger.error(f"Error generando artículo: {e}")
            return {"error": str(e), "content": ""}
