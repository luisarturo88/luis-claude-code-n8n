"""
Agente de extracción de entidades para LuisVet SEO AI

Construye un grafo de conocimiento veterinario conectando:
- Enfermedades
- Síntomas
- Tratamientos
- Especies afectadas
- Factores de riesgo
- Prevención
"""
import logging
import json
from typing import Dict, List, Optional
from openai import OpenAI

from config import OPENAI_API_KEY, OPENAI_MODEL, OPENAI_TEMPERATURE

logger = logging.getLogger(__name__)


class EntityAgent:
    """Agente especializado en extracción de entidades veterinarias."""
    
    def __init__(self):
        self.client = OpenAI(api_key=OPENAI_API_KEY)
    
    def extract(self, content: str) -> Dict:
        """
        Extraer entidades y construir grafo de conocimiento.
        
        Args:
            content: Contenido a analizar
            
        Returns:
            Diccionario con entidades y relaciones
        """
        logger.info("Extrayendo entidades...")
        
        try:
            prompt = f"""
Analiza el siguiente contenido y extrae todas las entidades veterinarias relevantes:

{content[:5000]}  # Limitar longitud para evitar problemas de tokens

Identifica y categoriza:
1. Enfermedades/Condiciones médicas
2. Síntomas
3. Tratamientos
4. Medicamentos
5. Especies animales afectadas
6. Razas predispuestas
7. Factores de riesgo
8. Métodos de diagnóstico
9. Medidas de prevención

Construye un grafo de conocimiento mostrando las relaciones entre entidades.

Formato JSON:
{{
    "entities": [
        {{"name": "nombre", "type": "enfermedad|síntoma|tratamiento|etc", "importance": 1-10}}
    ],
    "relationships": [
        {{"from": "entidad1", "to": "entidad2", "relation": "causa|sintoma_de|tratado_con|etc"}}
    ],
    "main_topic": "tema principal",
    "related_topics": ["tema1", "tema2"],
    "knowledge_graph": {{
        "central_node": "nodo central",
        "connected_nodes": ["nodo1", "nodo2"]
    }}
}}
"""
            
            response = self.client.chat.completions.create(
                model=OPENAI_MODEL,
                messages=[
                    {
                        "role": "system",
                        "content": "Eres un experto en terminología veterinaria. Responde solo con JSON válido."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.3,
                max_tokens=3000,
                response_format={"type": "json_object"}
            )
            
            result = json.loads(response.choices[0].message.content)
            
            logger.info(f"✓ {len(result.get('entities', []))} entidades extraídas")
            return result
            
        except Exception as e:
            logger.error(f"Error en extracción de entidades: {e}")
            return {
                "entities": [],
                "relationships": [],
                "main_topic": "",
                "related_topics": [],
                "knowledge_graph": {},
                "error": str(e)
            }
    
    def build_knowledge_graph(self, entities: List[Dict]) -> Dict:
        """
        Construir grafo de conocimiento a partir de entidades.
        
        Args:
            entities: Lista de entidades
            
        Returns:
            Grafo de conocimiento estructurado
        """
        graph = {
            "nodes": [],
            "edges": [],
            "clusters": {}
        }
        
        # Crear nodos
        for entity in entities:
            graph["nodes"].append({
                "id": entity.get("name", ""),
                "type": entity.get("type", "unknown"),
                "importance": entity.get("importance", 5)
            })
        
        # Agrupar por tipo (clusters)
        for entity in entities:
            entity_type = entity.get("type", "other")
            if entity_type not in graph["clusters"]:
                graph["clusters"][entity_type] = []
            graph["clusters"][entity_type].append(entity.get("name", ""))
        
        return graph
    
    def get_related_entities(self, main_entity: str, context: str = "") -> List[str]:
        """
        Obtener entidades relacionadas con una entidad principal.
        
        Args:
            main_entity: Entidad principal
            context: Contexto adicional
            
        Returns:
            Lista de entidades relacionadas
        """
        try:
            prompt = f"""
Para la entidad veterinaria "{main_entity}", lista 10 entidades relacionadas.
{f'Contexto: {context}' if context else ''}

Responde solo con una lista JSON de strings.
"""
            
            response = self.client.chat.completions.create(
                model=OPENAI_MODEL,
                messages=[
                    {"role": "user", "content": prompt}
                ],
                temperature=0.5,
                max_tokens=500,
                response_format={"type": "json_object"}
            )
            
            result = json.loads(response.choices[0].message.content)
            return result.get("related", [])
            
        except Exception as e:
            logger.error(f"Error obteniendo entidades relacionadas: {e}")
            return []


# Ejemplo de uso
if __name__ == "__main__":
    agent = EntityAgent()
    
    sample_content = """
    El parvovirus canino es una enfermedad viral altamente contagiosa que afecta 
    principalmente a cachorros. Los síntomas incluyen vómito, diarrea con sangre, 
    letargo y pérdida de apetito. El tratamiento consiste en hospitalización, 
    fluidoterapia y antibióticos para prevenir infecciones secundarias.
    La vacunación es la mejor prevención.
    """
    
    result = agent.extract(sample_content)
    print(json.dumps(result, indent=2, ensure_ascii=False))
