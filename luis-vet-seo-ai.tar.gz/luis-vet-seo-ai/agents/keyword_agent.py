"""
Agente de análisis de keywords para LuisVet SEO AI

Este agente analiza keywords veterinarias utilizando:
- Google Suggest
- Related Searches
- People Also Ask
- Análisis de competencia
- Estimación de dificultad
- Detección de intención de búsqueda
- Generación de long tail keywords
"""
import logging
import json
from typing import Dict, List, Optional
from openai import OpenAI

from config import (
    OPENAI_API_KEY, OPENAI_MODEL, OPENAI_TEMPERATURE,
    PROMPTS_DIR
)

logger = logging.getLogger(__name__)


class KeywordAgent:
    """Agente especializado en análisis de keywords veterinarias."""
    
    def __init__(self):
        self.client = OpenAI(api_key=OPENAI_API_KEY)
        self.prompt_template = self._load_prompt()
    
    def _load_prompt(self) -> str:
        """Cargar el prompt desde archivo."""
        try:
            with open(f"{PROMPTS_DIR}/seo.txt", 'r', encoding='utf-8') as f:
                return f.read()
        except FileNotFoundError:
            logger.warning("Prompt file not found, using default")
            return self._default_prompt()
    
    def _default_prompt(self) -> str:
        """Prompt por defecto si no se encuentra el archivo."""
        return """
Eres un experto en SEO veterinario. Analiza la keyword: {keyword}

Genera un análisis completo incluyendo:
- Keywords relacionadas
- Dificultad (0-100)
- Intención de búsqueda
- Long tail keywords
- Preguntas frecuentes

Formato JSON:
{{
    "keywords": [],
    "difficulty": 0,
    "intent": "",
    "search_volume": 0,
    "long_tail": [],
    "questions": [],
    "competition": ""
}}
"""
    
    def analyze(self, keyword: str) -> Dict:
        """
        Analizar una keyword y devolver información completa.
        
        Args:
            keyword: La keyword principal a analizar
            
        Returns:
            Diccionario con el análisis completo de la keyword
        """
        logger.info(f"Analizando keyword: {keyword}")
        
        try:
            # Preparar el prompt
            prompt = self.prompt_template.format(keyword=keyword)
            
            # Llamar a OpenAI
            response = self.client.chat.completions.create(
                model=OPENAI_MODEL,
                messages=[
                    {
                        "role": "system",
                        "content": "Eres un experto en SEO veterinario especializado en análisis de keywords. Responde siempre en formato JSON válido."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=OPENAI_TEMPERATURE,
                max_tokens=2000,
                response_format={"type": "json_object"}
            )
            
            # Parsear respuesta
            result = json.loads(response.choices[0].message.content)
            
            # Validar estructura mínima
            if 'keywords' not in result:
                result['keywords'] = [keyword]
            if 'difficulty' not in result:
                result['difficulty'] = 50
            if 'intent' not in result:
                result['intent'] = 'informativa'
            
            logger.info(f"✓ Keyword analizada: {len(result.get('keywords', []))} keywords encontradas")
            return result
            
        except Exception as e:
            logger.error(f"Error en análisis de keyword: {e}")
            # Devolver resultado mínimo en caso de error
            return {
                "keywords": [keyword],
                "difficulty": 50,
                "intent": "informativa",
                "search_volume": 0,
                "long_tail": [],
                "questions": [],
                "competition": "media",
                "error": str(e)
            }
    
    def get_related_keywords(self, keyword: str) -> List[str]:
        """Obtener keywords relacionadas específicas."""
        result = self.analyze(keyword)
        return result.get('keywords', [keyword])
    
    def get_questions(self, keyword: str) -> List[str]:
        """Obtener preguntas relacionadas (People Also Ask)."""
        result = self.analyze(keyword)
        return result.get('questions', [])
    
    def get_long_tail(self, keyword: str) -> List[str]:
        """Obtener keywords long tail."""
        result = self.analyze(keyword)
        return result.get('long_tail', [])
    
    def estimate_difficulty(self, keyword: str) -> int:
        """Estimar dificultad de la keyword (0-100)."""
        result = self.analyze(keyword)
        return result.get('difficulty', 50)
    
    def detect_intent(self, keyword: str) -> str:
        """Detectar intención de búsqueda."""
        result = self.analyze(keyword)
        return result.get('intent', 'informativa')


# Ejemplo de uso
if __name__ == "__main__":
    agent = KeywordAgent()
    result = agent.analyze("parvovirus canino")
    print(json.dumps(result, indent=2, ensure_ascii=False))
